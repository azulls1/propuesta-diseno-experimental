# Sitio web del proyecto

El sitio público acompañante de esta propuesta está disponible en:

**https://propuesta-diseno-experimental.iagentek.com.mx**

## 12 módulos

- `/` Inicio (rúbrica + módulos)
- `/motivacion` (C1)
- `/hipotesis` (C2)
- `/metodologia` (C3 — 40%)
- `/comparacion`
- `/redaccion` (C4)
- `/datasets`
- `/baselines`
- `/entregables` (este catálogo)
- `/como-funciona`
- `/autor`
- `/laboratorio` (clasificador en vivo, Wilcoxon, validador, comentarios)

## Stack

Angular 19 · Tailwind 4 · Forest DS · Docker Swarm · Traefik · Let's Encrypt.

Backend del laboratorio: HuggingFace Inference API + Supabase
(stack supabase-maestria del VPS iagentek).
