# Entregable — Actividad 1: Propuesta de Diseño Experimental

**Autor:** Adonai Samael Hernández Mata (azulls1) · azull.samael@gmail.com
**Asignatura:** Investigación en Inteligencia Artificial
**Programa:** Maestría en IA · 1er semestre
**Fecha:** 2026-06-10 18:36 UTC

## Mapeo a la rúbrica

| Criterio                                      | Peso | Ubicación en este entregable                     |
|-----------------------------------------------|-----:|--------------------------------------------------|
| C1 — Motivación argumentada                   | 20%  | `01-reporte/reporte.docx` § 1                    |
| C2 — Hipótesis + experimentos refutables      | 20%  | `01-reporte/reporte.docx` § 2                    |
| **C3 — Rigor, muestreo, sesgos, suficiencia** | **40%** | `01-reporte/reporte.docx` § 3 + § 4           |
| C4 — Redacción y presentación                 | 20%  | `01-reporte/reporte.docx` (todo el documento)    |

**Formato del entregable principal**: `reporte.docx` se abre con Calibri 12 e interlineado 1.5 en Word (cumple el enunciado). El `reporte.pdf` está incluido como alternativa para visualización rápida.

## Contenido

- **`01-reporte/`** — La propuesta académica en PDF y su fuente Markdown.
- **`02-wiki-analisis/`** — Desglose del enunciado del maestro siguiendo el método LLM-wiki de Karpathy. Material de apoyo, no parte del entregable evaluado.
- **`03-sitio-web/`** — Información del sitio web público que complementa el proyecto.

## Recursos en línea

- **Sitio web público**: https://propuesta-diseno-experimental.iagentek.com.mx
- **Repositorio GitHub**: https://github.com/azulls1/propuesta-diseno-experimental

El sitio incluye un laboratorio ejecutable: clasificador en vivo con HuggingFace,
calculadora Wilcoxon, validador de hipótesis y comentarios persistidos en Supabase.

## Verificación

| Archivo               | SHA-256 |
|-----------------------|---------|
| `01-reporte/reporte.md` | `7dfaeb6d7b1f58ef55fb053cd0d0b8533f8a09443227c270c019d892c73a7e1a` |
| `01-reporte/reporte.pdf` | `6777211ad77817e5e6cb454fc7ec9e37b775cbad69bbd39aed7fe5793cb09765` |
| `01-reporte/reporte.docx` | `ddbf1341c1b918fc9ef7bc7013f91fb5c10bee52e76e516051572c1ba9172b61` |
| `01-reporte/_header.tex` | `6fdd3248876e6ca3e0b6f30d9b7faef6858a4432ebfa6f8f77df61683a80bec0` |
| `02-wiki-analisis/00-tldr.md` | `e0e98e990ce2e043d7529b2222ceedb6d93a864afa5bf0e910197cb95b66c305` |
| `02-wiki-analisis/01-objetivo.md` | `1bde2b2e756d5baa04ff2c235a561afd217fe048d7a99448e17fbf08e4e20c08` |
| `02-wiki-analisis/02-descripcion-detallada.md` | `51ec12dcce805247aa1372449afa4f72f90d7d50f5367c9bd803220080e62a45` |
| `02-wiki-analisis/03-req-1-hipotesis.md` | `3b0a3c32931a401f305a73fe6fa8a601f7f46daaf8546d582a1ab4b2ca7a23dc` |
| `02-wiki-analisis/04-req-2-metodologia.md` | `f087935cb468819fc2066f84c5cc9b2700ecead98c9bb14aa2e6080b786ef89f` |
| `02-wiki-analisis/05-req-3-train-val.md` | `0d25a232178c4ec9ba9af8c7624ce7849c02f54b021ef356cd5a175b96363da0` |
| `02-wiki-analisis/06-req-4-comparacion.md` | `7bc1d93e5150e42f2b534e6cc5b773f940818fc1d63f1aa079fd88c9b9ef4d11` |
| `02-wiki-analisis/07-rubrica-explicada.md` | `46c3551e0c42c5660254c3bd0aa5b24c649119a76d901990fb659a13659ef0c9` |
| `02-wiki-analisis/08-glosario.md` | `6ba4e13459365d118d901a8ecc9af986aa96967a4b333537e3c6cfa87dcb6b5b` |
| `02-wiki-analisis/09-plan-redaccion.md` | `2da8fc29823f9c1807206441a8b9e65eb489522cbe807c030358da28cd9715f3` |
| `02-wiki-analisis/10-checklist-final.md` | `cb15903bcdab8f492d1c0830802f0f52574d577fcddc3533bdedca8a41b736f1` |
| `02-wiki-analisis/11-decisiones-pendientes.md` | `2aa8a51f5823c95d0869f9b7e77ac869ef6feaab22608881bb2313b42e8457a2` |
| `02-wiki-analisis/README.md` | `60013c03a6fb9e3fba5e382998083910321e84ce26006dc8fcd7b04f8cb99de9` |
| `00-enunciado-original/mexmiart07_act2.docx` | `9dc306fbb7b01eabcaf0fdb373b29252f49550ae7eafff0b0562adc1a3751616` |
| `03-sitio-web/README-sitio.md` | `fba545394a9007a1fd34c7f943df13ba936419bf97c09bd7b12d4efd916078aa` |

Generado el 2026-06-10 18:36 UTC con `tools/build_entregable_zip.py`.
